const tablaBody = document.querySelector('#tablaClientes tbody');
const btnAgregar = document.getElementById('btnAgregar');
const btnActualizar = document.getElementById('btnActualizar');
const modal = document.getElementById('modalCliente');
const cerrarModal = document.getElementById('cerrarModal');
const cancelarModal = document.getElementById('cancelarModal');
const tituloModal = document.getElementById('tituloModal');
const formCliente = document.getElementById('formCliente');

const inputId = document.getElementById('clienteId');
const inputNombre = document.getElementById('clienteNombre');
const inputCorreo = document.getElementById('clienteCorreo');
const inputTelefono = document.getElementById('clienteTelefono');
const inputDireccion = document.getElementById('clienteDireccion');

let clientes = [];
let selectedId = null;

// Renderizar tabla
function renderTabla() {
  tablaBody.innerHTML = '';
  clientes.forEach(c => {
    const tr = document.createElement('tr');
    tr.dataset.id = c.id;
    tr.innerHTML = `
      <td>${c.id}</td>
      <td>${c.nombre}</td>
      <td>${c.correo}</td>
      <td>${c.telefono}</td>
      <td>${c.direccion}</td>
    `;
    tr.addEventListener('click', () => seleccionarFila(tr, c.id));
    if (c.id === selectedId) tr.classList.add('selected');
    tablaBody.appendChild(tr);
  });
  btnActualizar.disabled = selectedId === null;
}

// Seleccionar fila
function seleccionarFila(tr, id) {
  const prev = document.querySelector('tr.selected');
  if (prev) prev.classList.remove('selected');
  tr.classList.add('selected');
  selectedId = id;
  btnActualizar.disabled = false;
}

// Abrir modal Agregar
btnAgregar.addEventListener('click', () => {
  tituloModal.textContent = 'Agregar Cliente';
  formCliente.reset();
  selectedId = null;
  modal.setAttribute('aria-hidden', 'false');
  inputId.focus();
});

// Abrir modal Actualizar
btnActualizar.addEventListener('click', () => {
  if (selectedId === null) return;
  const cliente = clientes.find(c => c.id === selectedId);
  if (!cliente) return;
  tituloModal.textContent = 'Actualizar Cliente';
  inputId.value = cliente.id;
  inputNombre.value = cliente.nombre;
  inputCorreo.value = cliente.correo;
  inputTelefono.value = cliente.telefono;
  inputDireccion.value = cliente.direccion;
  modal.setAttribute('aria-hidden', 'false');
  inputId.focus();
});

// Cerrar modal
cerrarModal.addEventListener('click', () => modal.setAttribute('aria-hidden', 'true'));
cancelarModal.addEventListener('click', () => modal.setAttribute('aria-hidden', 'true'));
window.addEventListener('keydown', e => { if(e.key==='Escape') modal.setAttribute('aria-hidden','true') });
modal.addEventListener('click', e => { if(e.target===modal) modal.setAttribute('aria-hidden','true') });

// Guardar cliente
formCliente.addEventListener('submit', e => {
  e.preventDefault();
  const idVal = Number(inputId.value);
  const nombre = inputNombre.value.trim();
  const correo = inputCorreo.value.trim();
  const telefono = inputTelefono.value.trim();
  const direccion = inputDireccion.value.trim();

  if (!idVal || !nombre || !correo) {
    alert('Por favor completa ID, Nombre y Correo');
    return;
  }

  const idx = clientes.findIndex(c => c.id === idVal);
  if (idx !== -1) {
    // Actualizar
    clientes[idx] = { id: idVal, nombre, correo, telefono, direccion };
    alert('Cliente actualizado (mock)');
  } else {
    // Agregar
    clientes.push({ id: idVal, nombre, correo, telefono, direccion });
    alert('Cliente agregado (mock)');
  }

  selectedId = null;
  modal.setAttribute('aria-hidden', 'true');
  renderTabla();
});

// Inicializar tabla
renderTabla();

